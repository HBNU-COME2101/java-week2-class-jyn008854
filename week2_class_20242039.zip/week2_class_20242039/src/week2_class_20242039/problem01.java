package week2_class_20242039;

public class problem01 {
	public static void main(String [] args ) {
		System.out.print("Hello World!.");
	}
}
