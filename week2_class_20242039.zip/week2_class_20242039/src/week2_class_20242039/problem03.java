package week2_class_20242039;
import java.util.Scanner;
public class problem03 {
	public static void main(String [] args) {
		System.out.println("생일 입력 하세요");
		Scanner scanner = new Scanner(System.in);
		int num = scanner.nextInt();
		int year = num /10000;
		int month = (num%10000) / 100;
		int day = (num%10000) % 100;

		System.out.println(year + "년 " + month + "월 " + day + "일");
		scanner.close();

	}
}
