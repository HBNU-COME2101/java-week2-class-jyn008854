package week2_class_20242039;

public class problem02 {
	public static void main(String [] args) {
		System.out.print(20242039 + "정예나");
	}
}
