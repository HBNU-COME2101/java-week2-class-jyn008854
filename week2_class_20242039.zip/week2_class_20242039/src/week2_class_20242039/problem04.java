package week2_class_20242039;
import java.util.Scanner;
public class problem04 {
	public static void main(String [] args) {
		System.out.println("여행지 입력하시오");
		Scanner scanner = new Scanner(System.in);
		String a = scanner.next();
		
		System.out.println("인원수 입력하시오");
		Scanner scanner2 = new Scanner(System.in);
		int b = scanner2.nextInt();
		
		System.out.println("숙박일 입력하시오");
		Scanner scanner3 = new Scanner(System.in);
		int c = scanner3.nextInt();
		
		System.out.println("1인당 항공료 입력하시오");
		Scanner scanner4 = new Scanner(System.in);
		int d = scanner4.nextInt();
		
		System.out.println("1방 숙박비 입력하시오");
		Scanner scanner5 = new Scanner(System.in);
		int e = scanner5.nextInt(); 
		
		int room = b / 2;
		if(b%2 != 0) room += 1;
		int sum = d*b+ e*room*c;
		System.out.println(b+"명의 "+a+" "+c+"박"+(c+1)+"일 여행에는 "+room+"개 필요하며 경비는 "+sum+"원입니다.");
		
		scanner.close();
		scanner2.close();
		scanner3.close();
		scanner4.close();
		scanner5.close();
	}
}
