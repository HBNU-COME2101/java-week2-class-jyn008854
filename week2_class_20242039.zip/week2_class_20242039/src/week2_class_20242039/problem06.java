package week2_class_20242039;
import java.util.Scanner;
public class problem06 {
	public static void main(String [] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.print("(x1,y1), (x2,y2)의 좌표를 입력하세요.");
		int a = scanner.nextInt();
		int b = scanner.nextInt();
		int c = scanner.nextInt();
		int d = scanner.nextInt();

		if (10 <= a && a <= 200 && 10 <= b && b <= 300 && 10 <= c && c <= 200 && 10 <= d && d <= 300)
			System.out.println("포함된다");
		else
			System.out.println("포함되지 않는다.");

		scanner.close();

	}	
}
