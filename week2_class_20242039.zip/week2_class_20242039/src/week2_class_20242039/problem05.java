package week2_class_20242039;
import java.util.Scanner;

public class problem05 {
	public static void main(String [] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.print("나이를 입력하세요");
		int num = scanner.nextInt();
		
		if (num<=0)
			System.out.println("나이는 양수로만 입력하세요.");
		else {
			int a = num / 10;
			int b = (num % 10) / 5;
			int c = (num % 10) % 5;
			int d = a+b+c;
			System.out.println("빨간 초 "+a+"개, 파란 초 "+b+"개, 노란 초 "+c+"개. 총 "+d+"개가 필요합니다.");}
		scanner.close();
	}
}
